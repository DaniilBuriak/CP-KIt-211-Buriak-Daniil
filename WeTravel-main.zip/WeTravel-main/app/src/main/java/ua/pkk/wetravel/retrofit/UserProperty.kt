package ua.pkk.wetravel.retrofit

data class UserProperty(
        val email: String,
        var password: String
)

